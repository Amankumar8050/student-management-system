<?php
include 'db.php';
$id = $_GET["id"];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $conn->query("UPDATE students SET name='$name', age='$age' WHERE id=$id");
    header("Location: dashboard.php");
}
$student = $conn->query("SELECT * FROM students WHERE id=$id")->fetch_assoc();
?>
<form method="post">
    Name: <input type="text" name="name" value="<?= $student['name'] ?>" required /><br>
    Age: <input type="number" name="age" value="<?= $student['age'] ?>" required /><br>
    <button type="submit">Update</button>
</form>