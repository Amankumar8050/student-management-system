<?php
session_start();
if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}
include 'db.php';
$result = $conn->query("SELECT * FROM students");
?>
<a href="add_student.php">Add Student</a> | <a href="logout.php">Logout</a>
<table border="1">
<tr><th>ID</th><th>Name</th><th>Age</th><th>Actions</th></tr>
<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row["id"] ?></td>
    <td><?= $row["name"] ?></td>
    <td><?= $row["age"] ?></td>
    <td>
        <a href="edit_student.php?id=<?= $row["id"] ?>">Edit</a> |
        <a href="delete_student.php?id=<?= $row["id"] ?>">Delete</a>
    </td>
</tr>
<?php } ?>
</table>