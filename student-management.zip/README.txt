Student Management System using PHP & MySQL

Instructions:
1. Import the following SQL to create the database:

CREATE DATABASE student_db;
USE student_db;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT
);

2. Set up a local server (XAMPP/WAMP) and place these files in the htdocs folder.
3. Open the browser and go to http://localhost/student-management/login.php
4. Use login credentials:
   Username: admin
   Password: admin123
