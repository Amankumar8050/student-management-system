<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $age = $_POST["age"];
    $conn->query("INSERT INTO students (name, age) VALUES ('$name', '$age')");
    header("Location: dashboard.php");
}
?>
<form method="post">
    Name: <input type="text" name="name" required /><br>
    Age: <input type="number" name="age" required /><br>
    <button type="submit">Add</button>
</form>